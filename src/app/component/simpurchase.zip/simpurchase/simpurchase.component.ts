import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-simpurchase',
  templateUrl: './simpurchase.component.html',
  styleUrls: ['./simpurchase.component.css']
})
export class SimpurchaseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
