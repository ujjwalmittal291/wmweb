import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-report-admin-portal',
  templateUrl: './report-admin-portal.component.html',
  styleUrls: ['./report-admin-portal.component.css']
})
export class ReportAdminPortalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
